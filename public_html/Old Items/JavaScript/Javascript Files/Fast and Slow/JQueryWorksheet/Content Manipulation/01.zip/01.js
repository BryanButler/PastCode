$(document).ready(function(){

var $link = $(this);
var $firstbox = $('#fred');
var $secondbox = $('#wilma');

$('a[href$=".pdf"]').addClass('pdflink');

$('#wb').mouseenter(function(){
	$('#wb').addClass('hover');

});
$('#wb').mouseleave(function(){
	$('#wb').removeClass('hover');

});

$('div.poem-stanza').addClass('highlight');
$('#helviticaButton').click(function(){
$('body').removeClass().addClass('afterClick');
});

$('#db').click(function(){
	$('body').removeClass().addClass('body').addClass('highlight');
	$('body').removeClass().addClass('body');
	$('#fred').removeClass('ding').removeClass('mermaid').addClass('highlight');
	$('#wilma').removeClass('mermaid').addClass('highlight');

});

$('#wb').click(function(){
	$('body').removeClass().addClass('ding');

});

$('#ar').click(function(){
	$('div.poem-stanza').removeClass('highlight').addClass('mermaid');

});
$firstbox.hide();
$secondbox.hide();
$('a.more').click(function()
{
	$firstbox.animate({opacity: 'toggle',height: 'toggle'},'slow');
	$secondbox.animate({opacity: 'toggle', height: 'toggle'},'slow');
	if ($(this).text() == 'read more')
	{
		
		$(this).text('read less');
	}
	else
	{
		$(this).text('read more');
	}
	return false;
});


});