$(document).ready(function() {
  // Use attr() to add an id, rel, and title.
  $('div.chapter a').attr({rel: 'external'});
});
